package com.shpp.p2p.cs.ldebryniuk.assignment11.rpn;

public class Assignment11Part1 {

    public static void main(String[] args) {
//        if (args.length == 0) {
//            System.out.println("sorry no arguments found");
//            return;
//        }

//        args = new String[]{"1+(2+3*(4+5-sin(45*cos(a))))/7", "a=55"}; //, {"4.78322"},
//        System.out.println(new Calculator().runCalc(args));

        new Tester().runTests(); // todo uncomment for tests
    }

}



