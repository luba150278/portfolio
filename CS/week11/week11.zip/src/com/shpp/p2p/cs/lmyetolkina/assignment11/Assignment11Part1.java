package com.shpp.p2p.cs.lmyetolkina.assignment11;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The task implements the calculation of the value of the function passed as an argument to the "main" method.
 * A function can contain variables whose values are also passed as arguments.
 * To calculate the function, an algorithm called "Reverse Polish Notation" is used.
 * The function is parsed once, and then it can be used repeatedly.
 */
public class Assignment11Part1 {
    /*The start formula*/
    private static String formula;
    /*The parsing formula*/
    private static final ArrayList<String> parsingFormula = new ArrayList<>();
    /*The calculated finish result*/
    private static double finishResult;
    /*Unique variables from the formula*/
    private static final Set<String> formulaVariables = new HashSet<>();
    /*Hashmap saves the formula variables and them values*/
    private static final HashMap<String, Double> variables = new HashMap<>();
    /*The arrays and strings with the regular expressions used to realise the task*/
    private static final Set<String> FUNCTIONS = new HashSet<>(Arrays.asList("sin", "cos", "tan", "asin", "acos", "atan", "exp", "sqrt", "ln", "log", "!"));
    private static final String MATH_SYMBOLS_AND_FUNC = "(sin)|(cos)|(asin)|(acos)|(ln)|(log)|(tan)|(atan)|(sqrt)|(exp)|[-+/*^%!]";
    private static final String NOT_MATH_SYMBOLS_AND_FUNC = "^(sin)|^(cos)|^(asin)|^(acos)|^(ln)|^(log)|^(tan)|^(atan)|^(sqrt)|^(exp)|[^-+/*^%!]";
    private static final String[] MATH_FUNCTIONS = new String[]{"sin", "cos", "asin", "acos", "ln", "log", "tan", "atan", "sqrt", "exp"};
    private static final String PARSE_STRING = "(sin)|(cos)|(tan)|(asin)|(acos)|(atan)|(sqrt)|(exp)|(ln)|(log)|((-)?([0-9]+)(\\.[0-9]+)?)|[+-]|[/*]|[%^!]|[)(]|([a-z0-9_]+)";
    /*Additional comments for the user*/
    private static StringBuilder commentString;

    public static void main(String[] args) {
        commentString = new StringBuilder();
        try {
            checkAndExtractData(args); //Check and extract data from formula and variables
            getParsingFormula(getPartsOfFormula()); //Parsing formula using "RPN" algorithm
            calculateResult(); //Place numeric values to the parsing formula

        } catch (NumberFormatException e) {
            commentString.append("Please, check your formula and/or variables names.\n");
        } catch (ArrayIndexOutOfBoundsException e) {
            commentString.append("The empty input data array! Please input formula and variables with data.\n");
        }
        printResult(args[0]); //Print result to the user
        useNewValueOfArguments(args[0]); //Use the parsing formula to calculate new variables values.
    }

    /**
     * Check the valid formula and arguments. Extract formula to string and arguments to HashMap
     * @param args - input data array
     */
    private static void checkAndExtractData(String[] args){
        checkFormula(args[0]);  // Check the formula applicability for calculations
        extractVariablesFromFormula(formula); //Extract variables from formula
        extractAndCheckVariablesFromInputArgs(arrayVariables(args));//Extract and check the variables
        variablesWithoutValue();//Check exists the formula variables without values and use 0.0 value for it
    }

    /**
     * After parsing the formula, we can use it many times for other arguments that are prompted for the user to enter.
     * @param formula - the start formula
     */
    private static void useNewValueOfArguments(String formula) {
        commentString = new StringBuilder();
        try {
            Scanner in = new Scanner(System.in);
            while (true) {
                System.out.print("Do you want to calculate the formula for another arguments? Y/N:");
                if (in.next().toLowerCase().equals("n")) return;

                for (String key : variables.keySet()) {
                    System.out.print("Input a value for variable " + key + ":");
                    variables.put(key, Double.parseDouble(in.next().replaceAll("[,]", ".")));
                }
                calculateResult();
                printResult(formula);
            }
        } catch (NumberFormatException e) {
            System.out.println("You input non-numeric argument value.Please, try again.");
        }
    }

    /**
     * Create the some check for formula
     * @param str - the start formula
     */
    private static void checkFormula(String str) {
        formula = deleteSpace(str);  //Delete all spaces.
        formula = correctFormula(formula); //Replace "," with "." and ":" with "/".
        checkSymbolsInFormula(formula); //Check the characters of the formula,there should be only letters, numbers, bods,
                                        // math symbols and the underscore character.
        checkExistMathSymbol(formula); //The formula must contain at least one math symbol
        checkPairOfParentheses(formula); //The formula must contain the same number of opening and closing parentheses
    }

    /**
     * Delete spaces in the string
     * @param str - The string from which all spaces are removed
     * @return The string without spaces
     */
    private static String deleteSpace(String str) {
        return str.replaceAll("\\s+", "").toLowerCase();
    }

    /**
     * Replace ":" from "/" and "," from "."
     * @param formula the formula before correction
     * @return the corrected formula string
     */
    private static String correctFormula(String formula) {
        String str = formula.replaceAll("[:]", "/");
        return str.replaceAll("[,]", ".");
    }

    /**
     * The formula should not contain characters that are not specified in the regular expression
     * @param formula - the checking formula
     */
    private static void checkSymbolsInFormula(String formula) {
        String str = formula.replaceAll("[a-z0-9:._+-/*^()%!]", "");
        if (str.length() > 0) {
            commentString.append("Error. Unacceptable symbols in the formula: ").append(str).append("\n");
        }
    }

    /**
     * The formula must contain at least one mathematical symbol
     * @param formula - the checking formula
     */
    private static void checkExistMathSymbol(String formula) {
        String str = formula.replaceAll(NOT_MATH_SYMBOLS_AND_FUNC, "");
        if (str.length() == 0) {
            commentString.append("Error. The formula hasn't any math symbols.\n");
        }
    }

    /**
     * Put the all variables to an array
     * @param args - the start data array
     * @return the variables data array
     */
    private static String[] arrayVariables(String[] args) {
        String[] s = new String[args.length - 1];
        if (args.length - 1 >= 0) System.arraycopy(args, 1, s, 0, args.length - 1);
        return s;
    }

    /**
     * The formula must contain the same number of opening and closing parentheses. Check it.
     * @param formula - the checking formula
     */
    private static void checkPairOfParentheses(String formula) {
        int openParentheses = formula.split("\\(").length - 1;
        int closeParentheses = formula.split("\\)").length - 1;
        if (formula.charAt(formula.length() - 1) == ')') closeParentheses++;
        if (openParentheses != closeParentheses) {
            commentString.append("Error. The formula must contain the same number of opening and closing parentheses! " + "But formula has ").append(openParentheses).append(" the opening parentheses and ").append(closeParentheses).append(" closing parentheses\n");
        }
    }

    /**
     * @param formula - the start formula
     */
    private static void extractVariablesFromFormula(String formula) {
        String pattern = "[a-z]+";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(formula);
        /*For the found alphabetic characters, we determine the variable name,
        checking the characters before and after the character.*/
        while (m.find()) {
            formulaVariables.add(defineNameVariable(formula, m.start()));
        }

        formulaVariables.removeAll(Arrays.asList(MATH_FUNCTIONS));  //Remove all functions from array
    }

    /**
     * Define the name variables in the formula.
     * Checking characters before letter should be to equal _ or number and after should be equal letter, number or _
     *
     * @param formula - the formula
     * @param index   index the letter symbol
     * @return - the name of variable in the formula
     */
    private static String defineNameVariable(String formula, int index) {
        StringBuilder result = new StringBuilder(formula.substring(index, index + 1));
        String prev;
        String next;

        /*Check characters before letter*/
        for (int i = index - 1; i >= 0; i--) {
            prev = formula.substring(i, i + 1);

            if (prev.equals("_")) {
                result.insert(0, "_");
            } else if (Character.isDigit(prev.charAt(0))) {
                result.insert(0, prev.charAt(0));
            } else {
                break;
            }
        }

        /*Check characters after letter*/
        for (int i = index + 1; i < formula.length(); i++) {
            next = formula.substring(i, i + 1);

            if (Character.isDigit(next.charAt(0)) || next.charAt(0) == '_' || Character.isLetter(next.charAt(0))) {
                result.append(next);
            } else {
                break;
            }
        }
        return result.toString();
    }

    /**
     * Extract variables and their values ​​from the input array to Hashmap and do some data validation:
     * 1. Check to exist the name of the variable (before "=" symbol).
     * 2. Check the name of the variable. The name can have just letters, numbers and _
     * 3. The value of the variable should be a double number.
     *
     * @param args - the start variables
     */
    private static void extractAndCheckVariablesFromInputArgs(String[] args) {
        String variable;
        String[] parts;

        for (String arg : args) {
            /*Delete all spaces*/
            variable = deleteSpace(arg);
            /*Check #1*/
            if (variable.charAt(0) == '=') {
                commentString.append("Error. You try to entry number without variable!\n");
            }
            parts = variable.split("=");
            /*Check #3*/
            try {
                /*Check #2*/
                checkNameVariable(parts[0]);
                /*We add to the array only those variables that are in the formula*/
                if (formulaVariables.contains(parts[0])) {
                    variables.put(parts[0], Double.parseDouble(parts[1].replaceAll("[,]", ".")));
                }
            } catch (NumberFormatException e) {
                commentString.append("Error. The Variable ").append(parts[0]).append(" hasn't the numeric value: ").append(parts[1]).append("\n");
            }
        }
    }

    /**
     * Check the name of the variable. The name can have just letters, numbers and _
     * @param variable - the variable in the input data array
     */
    private static void checkNameVariable(String variable) {
        String resultString = variable.replaceAll("[a-z0-9_]", "");

        if (resultString.length() > 0) {
            commentString.append("Error. Unacceptable symbols in one of the variable: ").append(resultString).append("\n");
        }
    }

    /**
     * Compare variables in a formula and in the input data. If the formula contains variables
     * that are not represented in the input array, put them to the hashmap with a value of 0.0
     */
    private static void variablesWithoutValue() {
        for (String item : formulaVariables) {
            if (!variables.containsKey(item)) variables.put(item, 0.0);
        }
    }

    /**
     *Get parts of the formula using regular expressions.
     * Add a zero before the unary minus to make the formula work correctly.
     */
    private static ArrayList<String> getPartsOfFormula() {
        String prev;
        formula = formula.replaceAll("\\(-", "(0 - ");
        ArrayList<String> result = new ArrayList<>();
        Pattern r = Pattern.compile(PARSE_STRING);
        Matcher m = r.matcher(formula);

        while (m.find()) {
            result.add(m.group(0));
        }
        prev = result.get(0);

        /*Additional check for unary minus*/
        for (int i = 1; i < result.size(); i++) {
            if (isDigit(result.get(i)) && isDigit(prev) || (isDigit(result.get(i)) && prev.equals(")")) || (isDigit(result.get(i)) && Character.isLetter(prev.charAt(prev.length() - 1)))) {
                result.add(i, "+");
            }
            prev = result.get(i);
        }
        return result;
    }

    /**
     *Get parsing formula by used "Reverse Polish Notation" algorithm
     * @param partOfFormula - the array with parts of the formula
     */
    private static void getParsingFormula(ArrayList<String> partOfFormula) {
        Stack<String> operationsStack = new Stack<>();
        String lastOperation;

        for (String part : partOfFormula) {
            /*If the part of formula is digit put it to the result array*/
            if (isDigit(part)) {
                parsingFormula.add(String.valueOf(Double.parseDouble(part)));
                continue;
            }

            /*If the part of the formula isn't digit make next steps*/
            if (isOperationOrFunction(part)) {
                /*If the part of formula is function, put it to the result array*/
                if (FUNCTIONS.contains(part)) {
                    parsingFormula.add(part);
                    continue;
                }

                /*If the part of the formula is a first operation put it to stack*/
                if (operationsStack.size() == 0) {
                    operationsStack.push(part);
                    continue;
                }
                else {
                    /*Otherwise save the operation as value of "last operation" and make next step*/
                    lastOperation = operationsStack.peek();
                }

                /*Compare the priorities of the current and last operations.
                  If the priority of the current operation is higher than the priority of the last one stored on the stack,
                  then we put it on the stack. Otherwise, we push the last operation and push the current one onto the stack.
                 */
                if (getOperationPriority(lastOperation) >= getOperationPriority(part)) {
                    parsingFormula.add(operationsStack.pop());
                }
                operationsStack.push(part);
                continue;
            }

            /*If the part of the formula is a '(' put it to stack*/
            if (part.equals("(")) {
                operationsStack.push(part);
                continue;
            }

            /*If the current part of the formula is ')', then we pop all operations from the stack
            into the resulting string until we meet the sign '(', do not put it in the string.*/
            if (part.equals(")")) {
                while (!operationsStack.peek().equals("(")) {
                    parsingFormula.add(operationsStack.pop());
                }
                operationsStack.pop();
                continue;
            }
            parsingFormula.add(part);
        }

        /*We put all the remaining data from the stack into an array*/
        while (!(operationsStack.size() == 0)) {
            parsingFormula.add(operationsStack.pop());
        }
    }

    /**
     * Check if the part of the formula is a number. First, we check if the string is a variable name that can contain numbers
     * @param partOfFormula - the checked string
     * @return true if the string is digit
     */
    private static boolean isDigit(String partOfFormula) {
        if (variables.containsKey(partOfFormula)) return false;
        Pattern r = Pattern.compile("((-)?([0-9])(\\.[0-9])?)");
        Matcher m = r.matcher(partOfFormula);
        return m.find();
    }

    /**
     * Check if the part of the formula is a math operation or function
     * @param partOfFormula - the checked string
     * @return true if string is the math operation or formula
     */
    private static boolean isOperationOrFunction(String partOfFormula) {
        Pattern r = Pattern.compile(MATH_SYMBOLS_AND_FUNC);
        Matcher m = r.matcher(partOfFormula);
        return m.find();
    }

    /**
     * Get priority to all math operations
     * @param operation - the math operation
     * @return the integer value of priority
     */
    private static int getOperationPriority(String operation) {
        switch (operation) {
            case ")":
            case "(":
                return 0;
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            case "%":
            case "^":
                return 3;

            default:
                return 4;
        }
    }

    /**
     * Calculate the numeric value of a function
     */
    private static void calculateResult() {
        /*Replace all variables in a formula with numeric values*/
        String[] rpnString = addVariableValue();

        try {
            /*Use stack to save the intermediate values*/
            Stack<Double> numbersStack = new Stack<>();

            double firstNumber, secondNumber;

            for (int i = 0; i < rpnString.length; i++) {

                if (isDigit(rpnString[i]))
                    numbersStack.push(Double.parseDouble(rpnString[i]));  /*If the part of formula is digit put it to the stack*/
                else {
                    if (FUNCTIONS.contains(rpnString[i])) {
                        /*If the part of formula is function find it value*/
                        if (!rpnString[i].equals("!")) {
                            numbersStack.push(findFunctions(rpnString[i], Double.parseDouble(rpnString[i + 1])));
                            i++;
                        } else {
                            /*For the factorial, we swap the parameters*/
                            numbersStack.pop();
                            numbersStack.push(findFunctions(rpnString[i], Double.parseDouble(rpnString[i - 1])));
                        }

                    } else {
                        /*If the part of formula is the math symbol find result*/
                        secondNumber = numbersStack.pop();
                        firstNumber = numbersStack.pop();
                        numbersStack.push(findOperation(rpnString[i], firstNumber, secondNumber));
                    }
                }
            }
            finishResult = numbersStack.pop();
        } catch (NullPointerException e) {
            commentString.append("Error! Please, check your formula and/or the arguments values.\n");
        }
        catch(EmptyStackException e){
            commentString.append("Error! Please, check your formula.\n");
        }

    }

    /**
     * Find the result of calculation the math functions
     * @param function - the function
     * @param number - the start number
     * @return the result of the calculation
     */
    private static double findFunctions(String function, double number) {

        switch (function) {
            case "sin":
                return Math.sin(number);
            case "cos":
                return Math.cos(number);
            case "tan":
                return Math.tan(number);
            case "asin":
                return Math.asin(number);
            case "acos":
                return Math.acos(number);
            case "atan":
                return Math.atan(number);
            case "sqrt":
                return Math.sqrt(number);
            case "exp":
                return Math.exp(number);
            case "ln":
                return Math.log(number);
            case "log":
                return Math.log10(number);
            case "!":
                int numberInt = (int) number;
                return factorial(numberInt);
            default:
                return 0;
        }
    }

    /**
     * Find the result of calculation the math operations
     * @param operation - the math operation
     * @param firstNumber - the first number value
     * @param secondNumber - the second number value
     * @return - the result of the calculation
     */
    private static double findOperation(String operation, double firstNumber, double secondNumber) {
        switch (operation) {
            case "+":
                return (firstNumber + secondNumber);
            case "-":
                return (firstNumber - secondNumber);
            case "*":
                return (firstNumber * secondNumber);
            case "/":
                return (firstNumber / secondNumber);
            case "%":
                return (firstNumber % secondNumber);
            case "^":
                return (Math.pow(firstNumber, secondNumber));
            default:
                return 0;
        }
    }

    /**
     * Calculate the factorial
     * @param number - the start number value
     * @return - the result of calculation
     */
    private static int factorial(int number) {
        int result = 1;
        if (number == 1 || number == 0) {
            return result;
        }
        result = number * factorial(number - 1);
        return result;
    }

    /**
     * Substituting numeric values into function variables
     * @return The finish array for calculation
     */
    private static String[] addVariableValue() {
        String[] result = new String[parsingFormula.size()];
        int i = 0;
        for (String x : parsingFormula) {
            if (variables.containsKey(x)) {
                result[i] = String.valueOf(variables.get(x));
            } else {
                result[i] = x;
            }
            i++;
        }
        return result;
    }

    /**
     * Print the result of the calculation for user
     * @param formula - the start formula
     */
    private static void printResult(String formula) {
        String s = "--------------------\n";
        StringBuilder finishText = new StringBuilder("FORMULA: " + formula + "\n");
        finishText.append(s);
        finishText.append("ARGUMENTS:\n");
        for (String key : variables.keySet()) {
            finishText.append(key).append(": ").append(variables.get(key)).append("\n");
        }
        finishText.append(s);
        finishText.append("RESULT*: ").append(finishResult).append("\n");
        finishText.append("*If the formula contains variables for which no numeric values are specified,\n" +
                "then the value 0 is substituted when calculating the result.\n");
        finishText.append(s);
        finishText.append((commentString.length()!=0) ? "COMMENTS:\n" + commentString + "Result may consist a wrong value!\n" + s: "");
        System.out.println(finishText);
    }
}
