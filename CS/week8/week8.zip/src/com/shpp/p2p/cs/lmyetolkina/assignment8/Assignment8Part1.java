package com.shpp.p2p.cs.lmyetolkina.assignment8;

import acm.graphics.GObject;
import acm.graphics.GOval;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Create and move balls changing direction by mouse click
 */

public class Assignment8Part1 extends WindowProgram {
    private final int COUNT_BALL = 10;
    private final int MOVING_BALL = 5;
    private final Color HORIZONTAL_MOVE_COLOR = Color.CYAN;
    private final Color VERTICAL_MOVE_COLOR = Color.GREEN;
    private double diameterBall;
    private int counter = 0;
    private final ArrayList<GOval> balls = new ArrayList<>();
    private static final double PAUSE_TIME = 20;
    private GOval ballClicked;
    double vx, vy;

    @Override
    public void mousePressed(MouseEvent mouseEvent) {
        double getX = mouseEvent.getX();
        double getY = mouseEvent.getY();
        ballClicked = getCollidingObject(getX, getY);
        if (ballClicked != null) {
            counter++;
        }
    }

    public void run() {
        addMouseListeners();
        /*Set diameter balls and create them*/
        setUpApp();
        waitForClick();
        /*Check direction of the ball*/
        checkDirectionBall();
        /*Move ball*/
        moveBall();
    }

    private void setUpApp() {
        double diagonal = diagonal(getWidth(), getHeight());
        diameterBall = diagonal / (COUNT_BALL - 1 + 2*Math.sqrt(2));
        createBalls();
    }

    private void createBalls() {
        double y = (getHeight() - diameterBall) / (COUNT_BALL - 1);
        GOval oval;
        for (int i = 0; i < COUNT_BALL; i++) {
            oval = new GOval(i * diameterBall, i * y, diameterBall, diameterBall);
            oval.setFilled(true);
            oval.setFillColor(HORIZONTAL_MOVE_COLOR);
            add(oval);
            balls.add(oval);
        }
    }

    /*Find length of the app diagonal*/
    private double diagonal(double p1, double p2) {
        return Math.sqrt(Math.pow(p1, 2) + Math.pow(p2, 2));
    }

    /*Check if the click mouse by ball or not*/
    private GOval getCollidingObject(double x, double y) {
        GObject object = getElementAt(x, y);
        if (object != null) {
            for (GOval ball : balls) {
                if (object.getX() == ball.getX() && object.getY() == ball.getY()) {
                    return ball;
                }
            }
        }
        return null;
    }

    /*Check direction of ball and change it*/
    private void checkDirectionBall() {
        if (ballClicked == null) return;

        if (ballClicked.getFillColor() == HORIZONTAL_MOVE_COLOR) {
            ballClicked.setFillColor(VERTICAL_MOVE_COLOR);
            vx = 5;
            vy = 0;
        } else {
            ballClicked.setFillColor(HORIZONTAL_MOVE_COLOR);
            vy = 5;
            vx = 0;
        }
        moveBall();
    }

    /*Move ball if it hits wall change direction*/
    private void moveBall(){
        while (counter <= MOVING_BALL) {
            ballClicked.move(vx, vy);
            double x = ballClicked.getX() + diameterBall;
            double y = ballClicked.getY() + diameterBall;
            if (x <= diameterBall || x >= getWidth()) vx = -vx;
            if (y <= diameterBall || y >= getHeight()) vy = -vy;
            pause(PAUSE_TIME);
        };
    }
}
